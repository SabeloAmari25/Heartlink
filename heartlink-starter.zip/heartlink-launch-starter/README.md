# Heartlink Worldwide — launch starter

This is a starter project for the worldwide Heartlink dating site. It includes a Next.js landing/sign-up page, Supabase email/password auth wiring, and an initial SQL schema with row-level security policies.

## Local setup
1. Install Node.js 20+.
2. Create a Supabase project at https://supabase.com/.
3. In Supabase SQL Editor, run `supabase/schema.sql`.
4. In Supabase Authentication settings, enable email/password and configure your site URL / redirect URLs for local development and production.
5. Copy `.env.example` to `.env.local` and fill in your Supabase project URL and anon/publishable key. Never put a service-role key in the browser.
6. Run `npm install`, then `npm run dev`. Open http://localhost:3000.

## Deploy
1. Push this folder to a GitHub repository.
2. Import that repository into Vercel.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel project environment variables.
4. Deploy, then add the production domain to Supabase Auth's Site URL and allowed redirect URLs.
5. Connect a domain you own in Vercel and configure its DNS as instructed by Vercel.

## Important status
This is not a production-ready dating platform yet. Profile creation/editing, image upload, discovery filters, mutual-match logic, chat UI, moderation dashboard, account deletion, privacy policy/terms, rate limits, age verification workflow, and security review still need to be completed and tested. The SQL is a starting point and needs a security review before real users' personal data is stored. For matching, create matches server-side or through a carefully validated database function; do not let clients create arbitrary match rows. Consider private storage buckets for profile photos and a report/block moderation process before launch.
