'use client';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function Home() {
  const [mode, setMode] = useState<'signup'|'login'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage('');
    const result = mode === 'signup'
      ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${location.origin}/` } })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    setMessage(result.error ? result.error.message : mode === 'signup' ? 'Account created. Check your email to verify your address.' : 'Signed in. Profile and discovery screens are the next build step.');
  }
  return <main className="shell">
    <nav className="nav"><div className="brand"><span className="heart">♥</span> heartlink</div><span className="global">A world of possibilities</span></nav>
    <section className="hero"><div className="copy"><p className="eyebrow">MEET BEYOND YOUR CIRCLE</p><h1>Real connections.<br/><em>Worldwide.</em></h1><p className="sub">Find someone who shares your values, your curiosity, and your next big adventure.</p><div className="chips"><span>🌍 Global community</span><span>💌 Meaningful dating</span><span>🔒 Adults 18+</span></div></div>
    <div className="card"><div className="tabs"><button className={mode==='signup'?'active':''} onClick={()=>{setMode('signup');setMessage('')}}>Create account</button><button className={mode==='login'?'active':''} onClick={()=>{setMode('login');setMessage('')}}>Log in</button></div><h2>{mode==='signup'?'Start your story':'Welcome back'}</h2><p className="muted">{mode==='signup'?'Join Heartlink and meet people around the world.':'Sign in to continue your journey.'}</p><form onSubmit={submit}><label>Email address</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/><label>Password</label><input type="password" minLength={8} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/><button className="primary" disabled={busy}>{busy?'Please wait…':mode==='signup'?'Create my account':'Log in'}</button></form>{message&&<p className="message" role="status">{message}</p>}<p className="fine">By continuing, you confirm you are 18 or older. Be kind, be honest, and keep personal information safe.</p></div></section>
    <footer>Heartlink · Made for meaningful connections · <a href="#safety">Safety first</a></footer><section id="safety" className="safety"><strong>Our promise:</strong> We’re building tools for reporting, blocking, and protecting your privacy before opening the platform to the public.</section>
  </main>
}
