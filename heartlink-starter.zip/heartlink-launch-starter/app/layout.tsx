import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Heartlink — Meet someone real', description: 'Discover meaningful connections around the world.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
