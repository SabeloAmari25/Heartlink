-- Heartlink starter schema. Run in Supabase SQL Editor after creating a project.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 50),
  birth_date date not null,
  country text not null,
  city text,
  bio text check (char_length(bio) <= 500),
  interests text[] not null default '{}',
  avatar_url text,
  created_at timestamptz not null default now(),
  constraint adult_only check (birth_date <= (current_date - interval '18 years')::date)
);
create table if not exists public.likes (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(from_user,to_user),
  check (from_user <> to_user)
);
create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  user_one uuid not null references public.profiles(id) on delete cascade,
  user_two uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (user_one < user_two),
  unique(user_one,user_two)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_user_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null,
  details text check (char_length(details) <= 2000),
  created_at timestamptz not null default now(),
  check (reporter_id <> reported_user_id)
);
create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id,blocked_id),
  check (blocker_id <> blocked_id)
);
alter table public.profiles enable row level security;
alter table public.likes enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;
alter table public.blocks enable row level security;
create policy "profiles readable to signed in users" on public.profiles for select to authenticated using (true);
create policy "users create own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "users manage own outgoing likes" on public.likes for all to authenticated using (auth.uid() = from_user) with check (auth.uid() = from_user);
create policy "participants read matches" on public.matches for select to authenticated using (auth.uid() = user_one or auth.uid() = user_two);
create policy "participants read messages" on public.messages for select to authenticated using (exists(select 1 from public.matches m where m.id=match_id and (m.user_one=auth.uid() or m.user_two=auth.uid())));
create policy "participants send messages" on public.messages for insert to authenticated with check (sender_id=auth.uid() and exists(select 1 from public.matches m where m.id=match_id and (m.user_one=auth.uid() or m.user_two=auth.uid())));
create policy "users create reports" on public.reports for insert to authenticated with check (reporter_id=auth.uid());
create policy "users manage own blocks" on public.blocks for all to authenticated using (blocker_id=auth.uid()) with check (blocker_id=auth.uid());
-- Production note: mutual-match creation should be implemented as a SECURITY DEFINER function
-- with careful validation, not as a client-side insert. Never expose the service-role key.
